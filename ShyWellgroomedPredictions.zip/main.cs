using System;

class Program {
  public static void Main (string[] args) {
        // Console.WriteLine("Enter a number:");
        // int num = Convert.ToInt32(Console.ReadLine());
        int num = 2;

      switch(num)
      {
          case 1: Console.WriteLine("value is 1");
            break;
          case 27: Console.WriteLine("Value is 2");
            break;
        default:
          Console.WriteLine("other than 1 and 2");
          break;
      } 
    /*
switch (expression){

case 1: //statement 1;
break;
case 2: //statement 2;
break;

*/
  }}